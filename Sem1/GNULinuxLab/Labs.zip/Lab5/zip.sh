while true
do
  zip $1 $2
  sleep $3
done
