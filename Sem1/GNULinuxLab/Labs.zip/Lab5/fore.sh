while true
do
  echo "read"
  read somevar
done
