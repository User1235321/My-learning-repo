while true
do
  echo "Some Message"
  sleep 5
done
