rsync -avu --delete $1 $2
