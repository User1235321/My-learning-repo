echo "Child is live"

read B

echo "Child is dead"
