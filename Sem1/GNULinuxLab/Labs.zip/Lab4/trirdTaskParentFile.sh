echo "Parent file is live"

./"${1}.sh"

echo "Parent is dead"
