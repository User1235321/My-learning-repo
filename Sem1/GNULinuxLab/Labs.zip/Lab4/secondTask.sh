let sum=firstNumber+secondNumber
echo "Сумма: ${sum}"

let diff=firstNumber-secondNumber
echo "Разница: ${diff}"

let prod=firstNumber*secondNumber
echo "Произведение: ${prod}"

let rat=firstNumber/secondNumber
echo "Отношение: ${rat}"

