grep $1 * -n >> $2
