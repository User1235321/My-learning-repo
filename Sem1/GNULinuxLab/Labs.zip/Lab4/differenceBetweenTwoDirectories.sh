diff -r $1 $2
