/* hsv2rgb.h */

struct hsv_colour {
   float h;
   float s;
   float v;
}; /* end struct */

struct rgb_colour {
   float r;
   float g;
   float b;
}; /* end struct */
