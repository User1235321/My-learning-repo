/* random.h
 * Header file for random number routines.
 * ------------------------------------------------------------
 */

double random01 (int *restart);

int    flip     (double p);

